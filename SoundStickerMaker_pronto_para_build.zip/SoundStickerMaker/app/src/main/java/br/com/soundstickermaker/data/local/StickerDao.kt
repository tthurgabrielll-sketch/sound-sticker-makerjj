package br.com.soundstickermaker.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface StickerDao {

    @Query("SELECT * FROM sound_stickers ORDER BY createdAtEpochMs DESC")
    fun observeAllStickers(): Flow<List<StickerEntity>>

    @Query("SELECT * FROM sound_stickers ORDER BY createdAtEpochMs DESC LIMIT :limit")
    fun observeRecentStickers(limit: Int = 6): Flow<List<StickerEntity>>

    @Query("SELECT * FROM sound_stickers WHERE id = :id LIMIT 1")
    suspend fun getStickerById(id: Long): StickerEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSticker(sticker: StickerEntity): Long

    @Delete
    suspend fun deleteSticker(sticker: StickerEntity)

    @Query("DELETE FROM sound_stickers")
    suspend fun deleteAll()
}
