package br.com.soundstickermaker.media

import android.content.Context
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.os.Handler
import android.os.Looper
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume

data class ProcessedMediaOutput(
    val outputVideoFile: File,
    val thumbnailFile: File,
    val durationMs: Long,
    val width: Int,
    val height: Int,
    val hasAudio: Boolean,
    val audioCodec: String,
    val videoCodec: String,
    val audioVideoSyncDeltaMs: Long
)

class MediaProcessor(private val context: Context) {

    companion object {
        const val ERROR_PROCESSING_FAILED =
            "Ocorreu uma falha ao processar o vídeo localmente. Tente novamente com outro arquivo."
    }

    @OptIn(UnstableApi::class)
    suspend fun processVideoPreservingAudio(
        metadata: VideoMetadataInfo,
        preserveOriginalResolution: Boolean,
        onProgressChanged: (Float) -> Unit
    ): Result<ProcessedMediaOutput> = withContext(Dispatchers.Main) {
        val outputDir = File(context.cacheDir, "processed").apply {
            if (!exists()) mkdirs()
        }
        val outputFile = File(outputDir, "temp_sticker_${System.currentTimeMillis()}.mp4")
        if (outputFile.exists()) outputFile.delete()

        val mediaItem = MediaItem.fromUri(metadata.sourceUri)

        val videoEffects = if (!preserveOriginalResolution &&
            maxOf(metadata.width, metadata.height) > 720
        ) {
            listOf(Presentation.createForHeight(720))
        } else {
            emptyList()
        }

        val editedMediaItem = EditedMediaItem.Builder(mediaItem)
            .setRemoveAudio(false)
            .setRemoveVideo(false)
            .setEffects(Effects(emptyList(), videoEffects))
            .build()

        suspendCancellableCoroutine { continuation ->
            val transformer = Transformer.Builder(context)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .setLooper(Looper.getMainLooper())
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(
                        composition: Composition,
                        exportResult: ExportResult
                    ) {
                        if (!continuation.isActive) return
                        onProgressChanged(1.0f)

                        val verification = verifyOutputIntegrity(
                            outputFile = outputFile,
                            fallbackThumbnail = metadata.previewThumbnailFile,
                            expectedHasAudio = metadata.hasAudioTrack
                        )
                        continuation.resume(verification)
                    }

                    override fun onError(
                        composition: Composition,
                        exportResult: ExportResult,
                        exportException: ExportException
                    ) {
                        if (!continuation.isActive) return
                        runCatching { outputFile.delete() }
                        continuation.resume(
                            Result.failure(
                                IllegalStateException(
                                    ERROR_PROCESSING_FAILED,
                                    exportException
                                )
                            )
                        )
                    }
                })
                .build()

            val progressHolder = ProgressHolder()
            val progressJob = launch {
                while (isActive) {
                    val state = transformer.getProgress(progressHolder)
                    if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                        onProgressChanged((progressHolder.progress / 100f).coerceIn(0.05f, 0.95f))
                    }
                    delay(120L)
                }
            }

            continuation.invokeOnCancellation {
                progressJob.cancel()
                Handler(Looper.getMainLooper()).post {
                    runCatching { transformer.cancel() }
                    runCatching { outputFile.delete() }
                }
            }

            try {
                transformer.start(editedMediaItem, outputFile.absolutePath)
            } catch (e: Exception) {
                progressJob.cancel()
                if (continuation.isActive) {
                    continuation.resume(
                        Result.failure(IllegalStateException(ERROR_PROCESSING_FAILED, e))
                    )
                }
            }
        }
    }

    private fun verifyOutputIntegrity(
        outputFile: File,
        fallbackThumbnail: File?,
        expectedHasAudio: Boolean
    ): Result<ProcessedMediaOutput> {
        if (!outputFile.exists() || outputFile.length() == 0L) {
            return Result.failure(IllegalStateException(ERROR_PROCESSING_FAILED))
        }

        val extractor = MediaExtractor()
        var videoDurationMs = 0L
        var audioDurationMs = 0L
        var hasAudio = false
        var videoCodec = "H.264 / AVC"
        var audioCodec = "Sem áudio original"

        try {
            extractor.setDataSource(outputFile.absolutePath)
            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME).orEmpty()
                val durMs = if (format.containsKey(MediaFormat.KEY_DURATION)) {
                    format.getLong(MediaFormat.KEY_DURATION) / 1000L
                } else {
                    0L
                }

                if (mime.startsWith("video/")) {
                    videoDurationMs = durMs
                    videoCodec = "H.264 / AVC"
                } else if (mime.startsWith("audio/")) {
                    hasAudio = true
                    audioDurationMs = durMs
                    audioCodec = "AAC-LC"
                }
            }
        } catch (e: Exception) {
            return Result.failure(IllegalStateException(ERROR_PROCESSING_FAILED, e))
        } finally {
            runCatching { extractor.release() }
        }

        if (expectedHasAudio && !hasAudio) {
            return Result.failure(IllegalStateException(ERROR_PROCESSING_FAILED))
        }

        val syncDelta = if (hasAudio && videoDurationMs > 0L && audioDurationMs > 0L) {
            kotlin.math.abs(videoDurationMs - audioDurationMs)
        } else {
            0L
        }

        val retriever = MediaMetadataRetriever()
        val finalDurationMs: Long
        val width: Int
        val height: Int
        try {
            retriever.setDataSource(outputFile.absolutePath)
            finalDurationMs = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_DURATION
            )?.toLongOrNull() ?: videoDurationMs
            width = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH
            )?.toIntOrNull() ?: 512
            height = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT
            )?.toIntOrNull() ?: 512
        } finally {
            runCatching { retriever.release() }
        }

        val thumbFile = fallbackThumbnail?.takeIf { it.exists() } ?: outputFile

        return Result.success(
            ProcessedMediaOutput(
                outputVideoFile = outputFile,
                thumbnailFile = thumbFile,
                durationMs = finalDurationMs,
                width = width,
                height = height,
                hasAudio = hasAudio,
                audioCodec = audioCodec,
                videoCodec = videoCodec,
                audioVideoSyncDeltaMs = syncDelta
            )
        )
    }
}
