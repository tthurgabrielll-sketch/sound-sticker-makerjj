package br.com.soundstickermaker.media

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.StatFs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

object VideoValidator {

    const val MAX_DURATION_MS = 10_000L
    private const val MIN_REQUIRED_FREE_BYTES = 25L * 1024L * 1024L

    const val ERROR_EXCEEDS_DURATION =
        "Este vídeo ultrapassa o limite de 10 segundos. Escolha um vídeo mais curto."
    const val ERROR_UNSUPPORTED_FORMAT =
        "Formato de vídeo não suportado. Selecione um arquivo MP4, MOV, MKV ou WebM válido."
    const val ERROR_CORRUPTED_FILE =
        "Não foi possível ler o arquivo selecionado. O vídeo pode estar corrompido."
    const val ERROR_NO_STORAGE_SPACE =
        "Espaço insuficiente no armazenamento interno do celular para processar a figurinha."

    private val SUPPORTED_VIDEO_MIMES = setOf(
        "video/avc",
        "video/hevc",
        "video/mp4v-es",
        "video/x-vnd.on2.vp8",
        "video/x-vnd.on2.vp9",
        "video/av01",
        "video/3gpp"
    )

    fun isDurationAllowed(durationMs: Long): Boolean {
        return durationMs in 1L..MAX_DURATION_MS
    }

    suspend fun validateVideoUri(context: Context, uri: Uri): VideoValidationResult =
        withContext(Dispatchers.IO) {
            if (!hasEnoughStorageSpace(context)) {
                return@withContext VideoValidationResult.Invalid(ERROR_NO_STORAGE_SPACE)
            }

            val fileSize = queryFileSize(context, uri)
            if (fileSize == 0L) {
                return@withContext VideoValidationResult.Invalid(ERROR_CORRUPTED_FILE)
            }

            val extractor = MediaExtractor()
            var hasVideo = false
            var hasAudio = false
            var videoMime = ""
            var audioMime = "Sem trilha de áudio"
            var extractorDurationMs = 0L

            try {
                extractor.setDataSource(context, uri, null)
                val trackCount = extractor.trackCount
                if (trackCount <= 0) {
                    return@withContext VideoValidationResult.Invalid(ERROR_CORRUPTED_FILE)
                }

                for (i in 0 until trackCount) {
                    val format = extractor.getTrackFormat(i)
                    val mime = format.getString(MediaFormat.KEY_MIME).orEmpty()
                    if (mime.startsWith("video/")) {
                        hasVideo = true
                        videoMime = mime
                        if (format.containsKey(MediaFormat.KEY_DURATION)) {
                            val trackDurMs = format.getLong(MediaFormat.KEY_DURATION) / 1000L
                            if (trackDurMs > extractorDurationMs) {
                                extractorDurationMs = trackDurMs
                            }
                        }
                    } else if (mime.startsWith("audio/")) {
                        hasAudio = true
                        audioMime = mime
                    }
                }
            } catch (_: Exception) {
                return@withContext VideoValidationResult.Invalid(ERROR_CORRUPTED_FILE)
            } finally {
                runCatching { extractor.release() }
            }

            if (!hasVideo) {
                return@withContext VideoValidationResult.Invalid(ERROR_UNSUPPORTED_FORMAT)
            }

            if (videoMime.isNotBlank() && videoMime !in SUPPORTED_VIDEO_MIMES) {
                return@withContext VideoValidationResult.Invalid(ERROR_UNSUPPORTED_FORMAT)
            }

            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(context, uri)
                val durationStr =
                    retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                val retrieverDurationMs = durationStr?.toLongOrNull() ?: extractorDurationMs

                if (retrieverDurationMs <= 0L) {
                    return@withContext VideoValidationResult.Invalid(ERROR_CORRUPTED_FILE)
                }

                if (retrieverDurationMs > MAX_DURATION_MS) {
                    return@withContext VideoValidationResult.Invalid(ERROR_EXCEEDS_DURATION)
                }

                val rawWidth = retriever.extractMetadata(
                    MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH
                )?.toIntOrNull() ?: 512
                val rawHeight = retriever.extractMetadata(
                    MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT
                )?.toIntOrNull() ?: 512
                val rotation = retriever.extractMetadata(
                    MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION
                )?.toIntOrNull() ?: 0

                val (effectiveWidth, effectiveHeight) = if (rotation == 90 || rotation == 270) {
                    rawHeight to rawWidth
                } else {
                    rawWidth to rawHeight
                }

                val thumbFile = extractThumbnailToCache(context, retriever)

                VideoValidationResult.Valid(
                    VideoMetadataInfo(
                        sourceUri = uri,
                        durationMs = retrieverDurationMs,
                        width = effectiveWidth,
                        height = effectiveHeight,
                        hasVideoTrack = true,
                        hasAudioTrack = hasAudio,
                        videoMimeType = videoMime,
                        audioMimeType = audioMime,
                        fileSizeBytes = fileSize,
                        previewThumbnailFile = thumbFile
                    )
                )
            } catch (_: Exception) {
                VideoValidationResult.Invalid(ERROR_CORRUPTED_FILE)
            } finally {
                runCatching { retriever.release() }
            }
        }

    private fun hasEnoughStorageSpace(context: Context): Boolean {
        return runCatching {
            val stat = StatFs(context.filesDir.absolutePath)
            stat.availableBytes >= MIN_REQUIRED_FREE_BYTES
        }.getOrDefault(true)
    }

    private fun queryFileSize(context: Context, uri: Uri): Long {
        return runCatching {
            context.contentResolver.openAssetFileDescriptor(uri, "r")?.use { afd ->
                afd.length
            } ?: -1L
        }.getOrDefault(-1L)
    }

    private fun extractThumbnailToCache(
        context: Context,
        retriever: MediaMetadataRetriever
    ): File? {
        return runCatching {
            val bitmap = retriever.getFrameAtTime(
                0L,
                MediaMetadataRetriever.OPTION_CLOSEST_SYNC
            ) ?: return null

            val cacheDir = File(context.cacheDir, "processed").apply {
                if (!exists()) mkdirs()
            }
            val thumbFile = File(cacheDir, "preview_thumb_${System.currentTimeMillis()}.jpg")
            FileOutputStream(thumbFile).use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
            }
            bitmap.recycle()
            thumbFile
        }.getOrNull()
    }
}
