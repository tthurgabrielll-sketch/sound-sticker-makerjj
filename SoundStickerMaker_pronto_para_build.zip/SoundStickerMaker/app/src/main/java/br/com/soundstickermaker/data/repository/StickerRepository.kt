package br.com.soundstickermaker.data.repository

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import br.com.soundstickermaker.data.local.StickerDao
import br.com.soundstickermaker.data.local.StickerEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class StickerRepository(
    private val context: Context,
    private val stickerDao: StickerDao
) {

    fun observeAllStickers(): Flow<List<StickerEntity>> = stickerDao.observeAllStickers()

    fun observeRecentStickers(limit: Int = 6): Flow<List<StickerEntity>> =
        stickerDao.observeRecentStickers(limit)

    suspend fun getStickerById(id: Long): StickerEntity? = stickerDao.getStickerById(id)

    suspend fun saveProcessedStickerToLibrary(
        tempVideoFile: File,
        tempThumbnailFile: File,
        durationMs: Long,
        width: Int,
        height: Int,
        hasAudio: Boolean,
        audioCodec: String,
        videoCodec: String,
        alsoExportToGallery: Boolean = true
    ): Result<StickerEntity> = withContext(Dispatchers.IO) {
        runCatching {
            val stickersDir = File(context.filesDir, "stickers").apply {
                if (!exists()) mkdirs()
            }

            val timestamp = System.currentTimeMillis()
            val formattedDate = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR"))
                .format(Date(timestamp))

            val permanentVideo = File(stickersDir, "sound_sticker_$timestamp.mp4")
            val permanentThumb = File(stickersDir, "thumb_$timestamp.jpg")

            tempVideoFile.copyTo(permanentVideo, overwrite = true)
            if (tempThumbnailFile.exists()) {
                tempThumbnailFile.copyTo(permanentThumb, overwrite = true)
            }

            if (alsoExportToGallery) {
                exportVideoToPublicGallery(permanentVideo)
            }

            val entity = StickerEntity(
                title = "Figurinha Sonora $formattedDate",
                videoFilePath = permanentVideo.absolutePath,
                thumbnailFilePath = permanentThumb.absolutePath,
                durationMs = durationMs,
                fileSizeBytes = permanentVideo.length(),
                width = width,
                height = height,
                hasAudio = hasAudio,
                audioCodec = audioCodec,
                videoCodec = videoCodec,
                createdAtEpochMs = timestamp
            )

            val insertedId = stickerDao.insertSticker(entity)
            entity.copy(id = insertedId)
        }
    }

    suspend fun deleteSticker(sticker: StickerEntity) = withContext(Dispatchers.IO) {
        runCatching { File(sticker.videoFilePath).delete() }
        runCatching { File(sticker.thumbnailFilePath).delete() }
        stickerDao.deleteSticker(sticker)
    }

    suspend fun clearTemporaryCache() = withContext(Dispatchers.IO) {
        val cacheDir = File(context.cacheDir, "processed")
        if (cacheDir.exists()) {
            cacheDir.listFiles()?.forEach { it.delete() }
        }
    }

    private fun exportVideoToPublicGallery(sourceFile: File) {
        runCatching {
            val resolver = context.contentResolver
            val contentValues = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, sourceFile.name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(
                        MediaStore.Video.Media.RELATIVE_PATH,
                        "${Environment.DIRECTORY_MOVIES}/SoundStickerMaker"
                    )
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }
            }

            val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            } else {
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            }

            val itemUri = resolver.insert(collection, contentValues) ?: return
            resolver.openOutputStream(itemUri)?.use { out ->
                sourceFile.inputStream().use { input ->
                    input.copyTo(out)
                }
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                contentValues.clear()
                contentValues.put(MediaStore.Video.Media.IS_PENDING, 0)
                resolver.update(itemUri, contentValues, null, null)
            }
        }
    }
}
