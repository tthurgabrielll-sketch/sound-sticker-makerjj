# Como gerar o APK

## Opção 1 — GitHub (sem instalar nada)
1. Crie um repositório no github.com e envie todo o conteúdo desta pasta.
2. Abra a aba **Actions** → **Build APK** → **Run workflow** (ou espere o build automático após o push).
3. Quando terminar (~5–8 min), clique na execução e baixe o artefato
   **SoundStickerMaker-debug-apk**. Dentro do .zip está o `app-debug.apk`.

## Opção 2 — Android Studio
1. File → Open → selecione a pasta SoundStickerMaker.
2. Aguarde o Gradle sincronizar.
3. Build → Build APK(s). O arquivo fica em `app/build/outputs/apk/debug/`.

## Opção 3 — Linha de comando (JDK 17 + Android SDK 35 + Gradle 8.9)
    gradle :app:assembleDebug
